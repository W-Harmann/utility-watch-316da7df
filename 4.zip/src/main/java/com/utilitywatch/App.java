package com.utilitywatch;

public class App {
    public static void main(String[] args) {
        Main.main(args);
    }
}
